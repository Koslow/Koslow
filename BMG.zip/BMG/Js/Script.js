function Clickedbutton1() {
    document.getElementById("click1").style.display = 'block';
}
function Clickedbutton2() {
    document.getElementById("click2").style.display = 'block';
}